
public class Activity1 {
	
	   public static void main(String [] args)
	   {
		   String s1 = "Java";
		   String s2 = "Java"; //interned string
		   compareString(s1, s2);
		   
		   s2 = new String("Java");
		   compareString(s1, s2);
		   
		   compareString("Java", "Hi");
	   }
	   
	   public static void compareString (String name1, String name2) {
			
			System.out.println(name1 + "==" + name2 + " is " + 
	                  (name1 == name2));
			System.out.println(name1 + ".equals(" + name2 + ") is " + 
	                   name1.equals(name2));
			System.out.println();
			
	   }


}
