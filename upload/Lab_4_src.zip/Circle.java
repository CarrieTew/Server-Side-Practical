
public class Circle {
	
	   private double radius;

	   public Circle(double r) {
	     radius = r;
	   }

	   //add the equals(Circle)
	   public boolean equals(Circle c) {
		   return c.radius == this.radius;
	   }

}
