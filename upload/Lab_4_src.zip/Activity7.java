import java.util.Scanner;

public class Activity7 {
	
	public static void main(String[] args) {
		//create a Scanner object to read input from user
		Scanner keyboard = new Scanner(System.in);
		
		//prompt the user to enter the matrix
		System.out.println("Enter a 3-by-4 matrix row by row:");
		
		//declare and create a 2D matrix
		double[][] matrix = new double[3][4];
		
		//reads the matrix and assigns it to the 2D matrix
		for(int i = 0; i < matrix.length; i++) {
			for(int j = 0; j < matrix[i].length; j++) {
				matrix[i][j] = keyboard.nextDouble();
			}
		}
		
		//process the matrix and displays the sum of each column
		for(int j = 0; j < matrix[0].length; j++) {
			//Sum of the elements at column 0 is 16.5
			System.out.println("Sum of the elements at column " + j + " is " + sumColumn(matrix, j));
		}
		
		keyboard.close();
		
	}
	
	//implement the sumColumn method
	public static double sumColumn(double[][] m, int columnIndex) {
		//complete body (implementation)
		double total = 0;
		for(int i = 0; i < m.length; i++) {
			total += m[i][columnIndex];
		}
		return total;
	}

}
