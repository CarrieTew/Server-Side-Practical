
public class Activity6 {
	
	public static void main(String[] args) {
		int [][] m1 = {{1,2},{3,4}};
		int [][] m2 = {{1,3},{2,4}};		
		int [][] res = addMatrix(m1, m2);
		for(int i=0; i<m1.length; i++) {
			for(int j=0; j<m1[i].length; j++) {
				System.out.print(res[i][j] + " ");			
			}
			System.out.println();
		}
	}
	
	public static int[][] addMatrix(int[][] a, int[][] b){
		int[][] result = new int[a.length][a[0].length];
		for(int row = 0; row < result.length; row++) {//loop through every row
			for(int col = 0; col < result[row].length; col++) {//loop through every column
				result[row][col] = a[row][col] + b[row][col];
			}
		}
		return result;
	}

}
