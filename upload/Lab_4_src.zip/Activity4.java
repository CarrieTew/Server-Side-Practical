import java.util.Scanner;

public class Activity4 {
	
	public static void main(String[] args) {
		
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Enter the number of students: ");
		int numberOfStudents = keyboard.nextInt();
		
		//declare and create an array
		int[] scores = new int[numberOfStudents];
		int best = 0;
		
		System.out.print("Enter " + numberOfStudents + " scores: "); //Enter 4 scores: 
		
		for(int i = 0; i < scores.length; i++) {
			scores[i] = keyboard.nextInt(); //reads the score and assigns it to the array
			
			//find the best score
			if(scores[i] > best) {
				best = scores[i];
			}
		}
		
		//assign grade
		char grade;
		for(int i = 0; i < scores.length; i++) {
			if(scores[i] >= best - 10) {
				grade = 'A';
			}else if(scores[i] >= best - 20) {
				grade = 'B';
			}else if(scores[i] >= best - 30) {
				grade = 'C';
			}else if(scores[i] >= best - 40) {
				grade = 'D';
			}else {
				grade = 'F';
			}
			
			//Student 0 score is 40 and grade is C
			System.out.println("Student " + i + " score is " + scores[i] + " and grade is " + grade);
		}
		
		keyboard.close();
	}

}
