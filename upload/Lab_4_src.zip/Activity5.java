import java.util.Arrays;

public class Activity5 {
	
	public static void main(String[] args) {
		
		int [] array = { 5,2,8,4,6,6,7};
		int [] sortedArray = descendSort(array);
		
		for(int i = 0; i < sortedArray.length; i++) {
			System.out.print(sortedArray[i] + " "); //display the sorted array
		}

	}
	
	public static int [] descendSort(int [] array) {
		int[] result = new int[array.length]; //create a new array (0 0 0 0 0 0 0) with the same size as the array passed in
		System.arraycopy(array, 0, result, 0, result.length);//5 2 8 4 6 6 7
		Arrays.sort(result);//2 4 5 6 6 7 8
		for(int i = 0; i < result.length/2; i++) {
			int temp = result[i];
			result[i] = result[result.length - 1 - i];
			result[result.length - 1 - i] = temp;
		}
		return result;
	}

}
