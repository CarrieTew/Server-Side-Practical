import java.util.Scanner;

public class Activity2 {
	
	public static void main(String[] args) {
		
		Scanner keyboard = new Scanner(System.in);
		
		boolean done = false;
		int count = 1;
		
		do {
			System.out.print("Enter the secret word: ");
			String secretWord = keyboard.nextLine();
			if(secretWord.equalsIgnoreCase("PASS")) {
				System.out.println("Congratulations! You know the secret word!");
				done = true; //flag the program to exit
			}else {
				System.out.println("Sorry that is NOT the secret word.");
				count++;
				if(count > 3) {
					System.out.println("You don't know the secret word.");
					done = true; //flag the program to exit
				}
			}
		}while(!done);
		
		keyboard.close();
		
	}

}
